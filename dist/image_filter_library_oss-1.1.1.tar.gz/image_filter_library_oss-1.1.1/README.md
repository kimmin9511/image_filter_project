이미지 필터 라이브러리  
BMP 이미지를 처리하기 위한 Python 라이브러리입니다. 주요 기능은 다음과 같습니다:  
  
jpg, png, 32bit bmp 파일을 24bit bmp 파일로 변환  
흑백 변환    
색상 반전  
픽셀화  
좌우 반전  
밝기 증가 및 피부 개선  
블러 처리  
얼굴 인식 후 입력된 문자열을 얼굴에 덮어씌우는 필터  
이외에도 다양한 필터가 있습니다.  
  
설치 방법  
pip install image-filter-library-oss==1.1.1  
  
ReadtheDocs  
https://app.readthedocs.org/projects/image-filter-project/  
  
testrepository  
https://github.com/jihoon0629/test\_repository
