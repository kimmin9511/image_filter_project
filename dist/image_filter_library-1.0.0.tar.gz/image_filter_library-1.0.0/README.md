이미지 필터 라이브러리
BMP 이미지를 처리하기 위한 Python 라이브러리입니다. 주요 기능은 다음과 같습니다:

흑백 변환
색상 반전
픽셀화
32비트 BMP를 24비트 BMP로 변환
설치 방법
GitHub에서 직접 설치: pip install git+https://github.com/yourusername/image_filter_project.git
